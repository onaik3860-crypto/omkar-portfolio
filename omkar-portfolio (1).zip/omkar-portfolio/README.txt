OMKAR NAik — DEVELOPER PORTFOLIO

HOW TO OPEN
1. Extract the ZIP file.
2. Open the extracted "omkar-portfolio" folder in VS Code.
3. Open index.html in your browser (double-click it from File Explorer).
4. Edit index.html for content, style.css for design, and script.js for interactions.

PERSONALIZE BEFORE PUBLISHING
- Replace your-email@example.com with your real email address.
- Replace the # links for GitHub and LinkedIn with your profile URLs.
- Add your real projects and certificates as you complete them.
- Check that the skill labels accurately reflect your current experience.

FILES
- index.html: website structure and content
- style.css: colors, layout, responsive design and animations
- script.js: mobile menu, current year and reveal effects

This is a static portfolio. It does not need a backend or API to run.
